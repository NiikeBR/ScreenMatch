package br.com.alura.screenmatch.modelos;

public class Series extends Title{
    private int seasons;
    private boolean active;
    private int epsSeason;
    private int epsMin;

    public Series(String name, int releaseDate) {
        super(name, releaseDate);
    }

    public int getSeasons() {
        return seasons;
    }

    public void setSeasons(int seasons) {
        this.seasons = seasons;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getEpsSeason() {
        return epsSeason;
    }

    public void setEpsSeason(int epsSeason) {
        this.epsSeason = epsSeason;
    }

    public int getEpsMin() {
        return epsMin;
    }

    public void setEpsMin(int epsMin) {
        this.epsMin = epsMin;
    }

    @Override
    public int getDurationInMinutes() {
        return seasons * epsSeason * epsMin;
    }

    @Override
    public String toString() {
        return "Série: " + this.getName() + " (" + this.getReleaseDate() + ")";
    }
}

package br.com.alura.screenmatch.Main;

import br.com.alura.screenmatch.calculos.RecomendationFilter;
import br.com.alura.screenmatch.calculos.TimeCalculator;
import br.com.alura.screenmatch.modelos.Episode;
import br.com.alura.screenmatch.modelos.Movie;
import br.com.alura.screenmatch.modelos.Series;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Movie myMovie = new Movie("O poderoso chefão", 1970);
        myMovie.setDurationInMinutes(180);
        System.out.println("Duração do filme: " + myMovie.getDurationInMinutes());

        myMovie.showSpecs();
        myMovie.rating(8);
        myMovie.rating(5);
        myMovie.rating(10);
        System.out.println("Total de avaliações: " + myMovie.getTotalRatings());
        System.out.println(myMovie.getAverage());
        /*myMovie.ratingSum = 10;
        myMovie.totalRatings = 1;
        System.out.println(myMovie.getAverage());*/

        Series lost = new Series("Lost", 2000);
        lost.showSpecs();
        lost.setSeasons(10);
        lost.setEpsSeason(10);
        lost.setEpsMin(50);
        System.out.println("Duração para maratonar: " + lost.getDurationInMinutes());

        Movie anotherMovie = new Movie("Avatar", 2023);
        anotherMovie.setDurationInMinutes(200);

        TimeCalculator calculator = new TimeCalculator();
        calculator.include(myMovie);
        calculator.include(anotherMovie);
        calculator.include(lost);
        System.out.println(calculator.getTotalDuration());

        RecomendationFilter filter = new RecomendationFilter();
        filter.filter(myMovie);

        Episode episode = new Episode();
        episode.setNumber(1);
        episode.setSerie(lost);
        episode.setTotalViews(300);
        filter.filter(episode);

        var filmeDoPaulo = new Movie("Dogville", 2003);
        filmeDoPaulo.setDurationInMinutes(200);
        filmeDoPaulo.rating(10);

        ArrayList<Movie> movieList = new ArrayList<>();
        movieList.add(filmeDoPaulo);
        movieList.add(myMovie);
        movieList.add(anotherMovie);
        System.out.println("Tamanho da lista " + movieList.size());
        System.out.println("Primeiro filme " + movieList.get(0).getName());
        System.out.println(movieList);
        System.out.println("toString do filme " + movieList.get(0).toString());






    }
}

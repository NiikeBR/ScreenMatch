package br.com.alura.screenmatch.calculos;

public interface Classification {
    int getClassification();
}

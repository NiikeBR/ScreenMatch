package br.com.alura.screenmatch.modelos;

public class Title implements Comparable<Title> {
    private String name;
    private int releaseDate;
    private boolean included;
    private double ratingSum;
    private int totalRatings;
    private int durationInMinutes;

    public Title(String name, int releaseDate) {
        this.name = name;
        this.releaseDate = releaseDate;
    }

    public int getTotalRatings(){
        return totalRatings;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setReleaseDate(int releaseDate) {
        this.releaseDate = releaseDate;
    }

    public int getReleaseDate() {
        return releaseDate;
    }

    public void setDurationInMinutes(int durationInMinutes) {
        this.durationInMinutes = durationInMinutes;
    }

    public void setIncluded(boolean included) {
        this.included = included;
    }

    public void showSpecs() {
        System.out.println("Nome do filme: " + name);
        System.out.println("Ano de lançamento: " + releaseDate);
    }

    public void rating(double rate) {
        ratingSum += rate;
        totalRatings++;
    }

    public double getAverage(){
        return ratingSum / totalRatings;
    }

    public int getDurationInMinutes() {
        return durationInMinutes;
    }

    @Override
    public int compareTo(Title otherTitle) {
        return  this.getName().compareTo(otherTitle.getName());
    }
}


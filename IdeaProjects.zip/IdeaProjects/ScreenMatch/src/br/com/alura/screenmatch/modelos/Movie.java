package br.com.alura.screenmatch.modelos;

import br.com.alura.screenmatch.calculos.Classification;

import javax.xml.namespace.QName;

public class Movie extends Title implements Classification {
    private String director;

    public Movie(String nome, int releaseDate) {
        super(nome, releaseDate);
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    @Override
    public int getClassification() {
        return (int) getAverage() / 2;
    }

    @Override
    public String toString() {
        return "Filme: " + this.getName() + " (" + this.getReleaseDate() + ")";
    }
}
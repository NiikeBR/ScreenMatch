package br.com.alura.screenmatch.calculos;

import br.com.alura.screenmatch.modelos.Movie;
import br.com.alura.screenmatch.modelos.Series;
import br.com.alura.screenmatch.modelos.Title;

public class TimeCalculator {
    private int totalDuration = 0;

    public int getTotalDuration() {
        return this.totalDuration;
    }

//    public void include(Movie f) {
//        this.totalDuration += f.getDurationInMinutes();
//    }
//
//    public void include(Series s) {
//        this.totalDuration += s.getDurationInMinutes();
//    }

    public void include(Title title){
        System.out.println("Adicionando duração em minutos de " + title);
        this.totalDuration += title.getDurationInMinutes();
    }
}
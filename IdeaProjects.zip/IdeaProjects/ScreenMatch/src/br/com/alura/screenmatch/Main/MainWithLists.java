package br.com.alura.screenmatch.Main;

import br.com.alura.screenmatch.modelos.Movie;
import br.com.alura.screenmatch.modelos.Series;
import br.com.alura.screenmatch.modelos.Title;

import java.util.*;

public class MainWithLists {
    public static void main(String[] args) {
        Movie myMovie = new Movie("O poderoso chefão", 1970);
        myMovie.rating(9);
        Movie anotherMovie = new Movie("Avatar", 2023);
        anotherMovie.rating(6);
        Series lost = new Series("Lost", 2000);
        var filmeDoPaulo = new Movie("Dogville", 2003);
        filmeDoPaulo.rating(10);

        Movie f1 = filmeDoPaulo;

        List<Title> list = new LinkedList<>();
        list.add(f1);
        list.add(myMovie);
        list.add(anotherMovie);
        list.add(lost);

        for (Title item: list) {
            System.out.println(item.getName());
            if (item instanceof Movie movie && movie.getClassification() > 2) {
                System.out.println("Classificação: " + movie.getClassification());
            }
        }

        List<String> searchForArtist = new ArrayList<>();
        searchForArtist.add("Adam Sandler");
        searchForArtist.add("Paulo");
        searchForArtist.add("Jacqueline");
        System.out.println(searchForArtist);

        Collections.sort(searchForArtist);
        System.out.println("Depois da ordenação ");
        System.out.println(searchForArtist);
        System.out.println("Lista de titulos ordenados");
        Collections.sort(list);
        System.out.println(list);
        list.sort(Comparator.comparing(Title::getReleaseDate));
        System.out.println("Ordenando por ano");
        System.out.println(list);

    }
}

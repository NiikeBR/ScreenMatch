import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double limite = 0;
        double custo = 0;
        String item;


        Scanner valorLimite = new Scanner(System.in);
        System.out.println("Digite o valor do limite: ");
        limite = valorLimite.nextDouble();

        Scanner itemDesejado = new Scanner(System.in);
        System.out.println("Digite a descrição da compra: ");
        item = itemDesejado.nextLine();

        Scanner valorDaCompra = new Scanner(System.in);
        System.out.println("Digite o valor da compra: ");
        custo = valorDaCompra.nextDouble();

        if (custo <= limite) {
            System.out.println("Compra realizada!!");
        } else {
            System.out.println("Limite insuficiente!!");
        }

    }
}
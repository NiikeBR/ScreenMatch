import java.util.ArrayList;
import java.util.List;

public class CartãoDeCredito {
    private double limite;
    private double saldo;
    private List<Compras> compras;

    public double getLimite() {
        return limite;
    }

    public List<Compras> getCompras() {
        return compras;
    }

    public double getSaldo() {
        return saldo;
    }

    public CartãoDeCredito(double limite) {
        this.limite = limite;
        this.saldo = limite;
        this.compras = new ArrayList<>();
    }

    public boolean lancaCompra(Compras compra) {
        if (this.saldo > compra.getValor()) {
            this.saldo -= compra.getValor();
            return true;
        }
        this.compras.add(compra);
        return false;

    }
}
